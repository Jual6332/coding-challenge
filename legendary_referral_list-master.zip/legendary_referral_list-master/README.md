# Legendary Referral List
A referral list application built for Ambassador Software Interview process. Back-end built with a Django_RESTAPI and front-end built with ReactJS components. 

## How can I test this Application?
From root directory run:
```python
python3 manage.py runserver
```
This will start the back-end server on localhost:8000.
